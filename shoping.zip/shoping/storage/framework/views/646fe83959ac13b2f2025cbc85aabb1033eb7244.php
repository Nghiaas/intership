<?php $__env->startSection('content'); ?>
<div class="col-md-4">
	<?php if(Session::has('message')): ?>
	<div class="alert alert-success text-center">
		<strong>Congratulation</strong>
		<?php echo e(Session::get('message')); ?>

	</div>
	<?php endif; ?>
</div>
<div class="col-md-11">
	<h3 style=" text-transform: uppercase;">Create New Category</h3>
	<?php echo e(Form::open(['url'=>'category','method'=>'post'])); ?>

	<div class="form-group">
		<?php echo e(Form::label('name')); ?>

		<?php echo e(Form::text('name','',['class'=>'form-control','placeholder'=>'enter name'])); ?>

		<?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
    <div class="text text-danger"><?php echo e($message); ?></div>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
	</div>
	<div class="form-group">
		<?php echo e(Form::label('description')); ?>

		<?php echo e(Form::textarea('description','',['class'=>'form-control','placeholder'=>'enter description'])); ?>

		<?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
    <div class="text text-danger"><?php echo e($message); ?></div>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
	</div>
	<div class="form-group">
	<?php echo e(Form::submit('send',['class'=>'btn btn-primary'])); ?> 
	<a href="<?php echo e(url('category')); ?>" class="btn btn-info">Back To List</a>
</div>
	<?php echo e(Form::close()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoping\resources\views/frontend/category/create.blade.php ENDPATH**/ ?>