<?php $__env->startSection('content'); ?>
<div class="col-md-4">
	<?php if(Session::has('update')): ?>
	<div class="alert alert-success text-center">
		<strong>Happy You</strong>
		<?php echo e(Session::get('update')); ?>

	</div>
	<?php endif; ?>
</div>
<div class="col-md-11">
	<h2 style=" text-transform: uppercase;">Update Brand</h2>
	<?php echo e(Form::open(['route'=>['brand.update',$brand->id],'method'=>'put'])); ?>

	<div class="form-group">
		<?php echo e(Form::label('name')); ?>

		<?php echo e(Form::text('name',$brand->name,['class'=>'form-control','placeholder'=>'enter name'])); ?>

	</div>
	<div class="form-group">
		<?php echo e(Form::label('description')); ?>

		<?php echo e(Form::textarea('description',$brand->description,['class'=>'form-control','placeholder'=>'enter description'])); ?>

	</div>
	<div class="form-group">
	<?php echo e(Form::submit('send',['class'=>'btn btn-primary'])); ?> 
	<a href="<?php echo e(url('brand')); ?>" class="btn btn-info">Back To List</a>
</div>
	<?php echo e(Form::close()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoping\resources\views/frontend/brand/edit.blade.php ENDPATH**/ ?>