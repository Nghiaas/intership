<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
    <div class="row">
        <div class="col-md-8 mx-auto">
           <?php if(Session::has('success')): ?>
     <div class="alert alert-success">
       <?php echo e(Session::get('success')); ?>

     </div>
     <?php endif; ?>
          <ul class="list-group">
          <li class="list-group-item active">Product infomation</li>
          <li class="list-group-item"><?php echo e($product->product_name); ?></li>
          <li class="list-group-item"><?php echo e($product->product_code); ?></li>
          <li class="list-group-item"><?php echo e($product->price); ?></li>
          <li class="list-group-item"><?php echo e($product->product_image); ?></li>

        </ul>
        <hr/>
            <?php echo Form::open(['url' => 'checkout', 'method' => 'get']); ?>

            <input type="number" value="<?php echo e($id); ?>" name="id" hidden="hidden"><br/>
            <label>Quantity</label>
            <input class="form-control" type="number" value="1" name="quantity">
                      
            <label>Customer</label>
            <?php echo e(Form::select('customer_id', $customer,'',['class' => 'form-control'] )); ?>

            <?php echo e(Form::submit('checkout',['class'=>'btn btn-primary mt-2'])); ?>

           <a href="<?php echo e(url('abc')); ?>" class="btn btn-info mt-2">Back </a>
          <?php echo Form::close(); ?>

            
        </div>
        
    </div>
<?php /**PATH C:\xampp\htdocs\shoping\resources\views/user/checkout.blade.php ENDPATH**/ ?>