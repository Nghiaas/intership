<?php $__env->startSection('content'); ?>

    <div class="row">
        <?php if(Session::has('update')): ?>
       <div class="alert alert-success">
  <strong>Success!</strong> <?php echo e(Session::get('update')); ?>

</div>
        <?php endif; ?>
    </div>
    
        <div class="col-md-11">
             <h3 class="text-center">update Order</h3>
        <?php echo e(Form::open(['route'=>['order.update',$order->id],'method'=>'put'])); ?>

        
                
           <div class="row">
              
                     <?php echo e(Form::label('', 'status')); ?> 
            <?php echo e(Form::text('status', '',['class' => 'form-control','placeholder'=>'please enter status'])); ?>

            
           </div>
        
        
		 <div class="form-group">
            <?php echo e(Form::submit('Save',['class' => 'btn btn-primary'])); ?>

            <a href="<?php echo e(url('order')); ?>" class="btn btn-info">Back to List</a>
        </div>
        <?php echo e(Form::close()); ?>

        	</div>
       
        
        
       
    
    </div>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoping\resources\views/frontend/orders/edit.blade.php ENDPATH**/ ?>