<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">Brand</a>
  <a class="navbar-brand" href="#"><img src="images/apple.png" style="width: 30px;"></a>
  

  
    <ul class="nav justify-content-end">
       <li class="nav-item">
    <a class="nav-link active" href="<?php echo e(url('admincp/login')); ?>" style="margin-left: 600px;">Login</a>
    
  </li>
    <li class="nav-item">
    <a class="nav-link active" href="<?php echo e(url('register')); ?>">Regristration</a>
    
  </li>

     
    
       
   
     
    </ul>
   

</nav><?php /**PATH C:\xampp\htdocs\shoping\resources\views/User/header.blade.php ENDPATH**/ ?>