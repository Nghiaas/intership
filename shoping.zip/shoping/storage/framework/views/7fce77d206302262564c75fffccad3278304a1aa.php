  <div class="container text-center footer">
   <div class="row">
    <div class="col-md-3">
      <ul class="nav-pill">
        <li><a href="">About Us</a></li>
        <li><a href="">Blog </a></li>
      </ul>
    </div>
    <div class="col-md-3">
      <ul class="nav-pill">
        <li><a href="">Product For Mac</a></li>
        <li><a href="">Product for Windows</a></li>
      </ul>
    </div>
    <div class="col-md-3">
      <ul class="nav-pill">
        <li><a href="">Web Analysics</a></li>
        <li><a href="">Presentations</a></li>
      </ul>
    </div>
    <div class="col-md-3">
      <ul class="nav-pill">
        <li><a href="">Product Help</a></li>
        <li><a href="">Develop API</a></li>
      </ul>
    </div>
   </div>
   <div class="row ">
     <div class="col-sm-12 text-center">
      <span>@2019  Company Nghia</span>
     </div>
  
   </div><?php /**PATH C:\xampp\htdocs\shoping\resources\views/User/footer.blade.php ENDPATH**/ ?>