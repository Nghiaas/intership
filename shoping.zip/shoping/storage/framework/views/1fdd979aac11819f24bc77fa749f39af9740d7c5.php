<?php $__env->startSection('content'); ?>
<div class="col-md-4" style="margin-top: 2px;">
      <?php if(Session::has('destroy')): ?>
      <div class="alert alert-danger text-center">
            <?php echo e(Session::get('destroy')); ?>

      </div>
      <?php endif; ?>
</div>


<!-- <h4><strong>Tìm thấy <span class="text-danger"><?php echo e(count($product)); ?></span> sản phẩm</strong></h4> -->
  
      <div class="col-md-11">
        <div class="row">
          <div class="col-md-2">
            <a href="<?php echo e(url('product/create')); ?>" class="btn btn-success" title="Create New Product"> <i class="fas fa-plus" style="margin-right: 4px;"></i></a>
          </div>
          <div class="col-md-4">
               <marquee direction="right">Manger Product </marquee>
          </div>
          <div class="col-md-4">
          <!--   <form class="form-inline" method="get" role="search" action="<?php echo e(url('timkiem)
          ')); ?>">
      <input class="form-control " type="search" placeholder="Search" aria-label="Search" name="keyy" style="margin :4px 0px 2px 10px;">
      <button class="btn btn-secondary" type="submit">Search</button>
    </form> -->
          </div>
        </div>
      </div>
	<table class="table table-bordered table-hover">
		<thead class="btn-primary">
			<th>No</th>
			<th>Product Code</th>
                <th>Product Name</th>
                <th>Description</th>
                <th>Brand</th>
                <th>Category</th>
                <th>Price</th>
                <th>Image</th>
                <th >Action</th>
		</thead>	
      <tbody>
      	<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      	<tr>
      		<td><?php echo e(++$key); ?></td>
      		<td><?php echo e($products->product_code); ?></td>
          <td><?php echo e($products->product_name); ?></td>
          <td><?php echo e(str_limit($products->description, $limit = 20, $end = '...')); ?>

           </td>
            <td><?php echo e($products->brand->name); ?></td>
            <td><?php echo e($products->category->name); ?></td>
      		<td><?php echo e($products->price); ?></td>
          <td><img src="images/<?php echo e($products->image); ?>" width="100px" height="80px" alt="..."></td>
               
                
      		<td>
      			<a href="<?php echo e(route('product.show',$products->id)); ?>" class="btn btn-primary">Show</a>
      			<a href="<?php echo e(route('product.edit',$products->id)); ?>" class="btn btn-success">Edit</a>
      			
                       <!--   Start section delete modal -->
                       <!-- Button to Open the Modal -->
<button type="button" class="btn btn-danger" data-toggle="modal" data-target="#Delete">
  Delete
</button>

<!-- The Modal -->
<div class="modal" id="Delete">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">  <strong>Warning</strong></h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">

         <h3>Did You Sure Delete Data Field This?</h3>
                        
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
            <?php echo e(Form::open(['route'=>['product.destroy',$products->id],'method'=>'delete'])); ?>

                        <?php echo e(Form::button('Delete',['class'=>'btn btn-danger','type'=>'submit'])); ?>

        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        <?php echo e(Form::close()); ?>

      </div>

    </div>
  </div>
</div>
                        <!--  Endsection delete modal -->

      		</td>
      	</tr>
      	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
	</table>
<div class="col-md-11">
  <?php echo e($product->links()); ?>

</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoping\resources\views/frontend/product/index.blade.php ENDPATH**/ ?>