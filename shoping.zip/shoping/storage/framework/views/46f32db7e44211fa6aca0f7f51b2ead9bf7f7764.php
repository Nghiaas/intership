<div class="row">
        <div class="col-md-3">
            <div class="list-group">
              <a href="#" class="list-group-item list-group-item-action active">Category</a>
              <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <a href="<?php echo e(route('productIncategory',$category->id)); ?>" class="list-group-item list-group-item-action"><?php echo e($category->name); ?></a>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <br/>
            <div class="list-group">
              <a href="#" class="list-group-item list-group-item-action active">Brand</a>
              <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <a href="<?php echo e(route('productInbrand',$brand->id)); ?>" class="list-group-item list-group-item-action"><?php echo e($brand->name); ?></a>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="col-md-9">
            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card col-md-4" style="float: left; margin-bottom: 25px;">
              <img height="220px" src="/DuyCD/public/Upload/<?php echo e($product->product_image); ?>" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title text-center"><?php echo e($product->product_name); ?></h5>
                <p class="card-text text-center">Price: <?php echo e($product->price); ?> $</p>
                
                <a href="<?php echo e(route('checkoutconfirm',$product->id)); ?>" class="btn btn-primary col-md-4 bg-success" style="float: left;">Buy</a>
                <a href="#" class="btn btn-primary col-md-7" style="margin-left: 15px;">Detail</a>

              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
        
    </div><?php /**PATH C:\xampp\htdocs\shoping\resources\views/admin/index.blade.php ENDPATH**/ ?>