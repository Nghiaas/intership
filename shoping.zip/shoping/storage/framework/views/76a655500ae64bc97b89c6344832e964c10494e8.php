<?php $__env->startSection('content'); ?>
<div class="col-md-4">
	<?php if(Session::has('update')): ?>
	<div class="alert alert-success text-center">
		<strong>Happy You</strong>
		<?php echo e(Session::get('update')); ?>

	</div>
	<?php endif; ?>
</div>
<div class="col-md-11">
	<h2 style=" text-transform: uppercase;">Update Category</h2>
	<?php echo e(Form::open(['route'=>['category.update',$cg->id],'method'=>'put'])); ?>

	<div class="form-group">
		<?php echo e(Form::label('name')); ?>

		<?php echo e(Form::text('name',$cg->name,['class'=>'form-control','placeholder'=>'enter name'])); ?>

	</div>
	<div class="form-group">
		<?php echo e(Form::label('description')); ?>

		<?php echo e(Form::textarea('description',$cg->description,['class'=>'form-control','placeholder'=>'enter description'])); ?>

	</div>
	<div class="form-group">
	<?php echo e(Form::submit('send',['class'=>'btn btn-primary'])); ?> 
	<a href="<?php echo e(url('category')); ?>" class="btn btn-info">Back To List</a>
</div>
	<?php echo e(Form::close()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoping\resources\views/frontend/category/edit.blade.php ENDPATH**/ ?>