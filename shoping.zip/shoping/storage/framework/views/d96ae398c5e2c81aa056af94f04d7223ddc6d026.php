<?php $__env->startSection('content'); ?>
<div class="col-md-11">
	<h3 class="text-center" style="text-transform: uppercase;">Show Category</h3>
	<div class="text-body text-center">
		
			<div class="form-group">
				<strong>Name:</strong> <?php echo e($category->name); ?> </br>
			</div>
			<div class="form-group">
					<strong>Description:</strong> <?php echo e($category->description); ?>


			</div>
			<div class="form-group">
				<a href="<?php echo e(url('category')); ?>" class="btn btn-info">Back To List</a>
			</div>
	
		
	
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoping\resources\views/frontend/category/show.blade.php ENDPATH**/ ?>