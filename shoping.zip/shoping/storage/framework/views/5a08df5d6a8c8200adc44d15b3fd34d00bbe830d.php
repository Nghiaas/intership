<?php $__env->startSection('content'); ?>

    <div class="row">
        <?php if(Session::has('message')): ?>
       <div class="alert alert-success">
  <strong>Success!</strong> <?php echo e(Session::get('message')); ?>

</div>
        <?php endif; ?>
    </div>
    
        <div class="col-md-11">
             <h3 class="text-center">Create Order</h3>
        <?php echo e(Form::open(['url'=>'order','method'=>'post'])); ?>

        <div class="row">
        	<div class="col-md-6">
                 <?php echo e(Form::label('', 'order_number')); ?> 
            <?php echo e(Form::number('order_number', '',['class' => 'form-control','placeholder'=>'please enter description'])); ?>

            <?php if ($errors->has('order_number')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('order_number'); ?>
    <div class="text text-danger"><?php echo e($message); ?></div>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
            <div class="col-md-6">
                <?php echo e(Form::label('', 'transaction')); ?> 
                    <?php echo e(Form::date('transaction',$transaction_date,['class' => 'form-control'])); ?>

            </div>
        </div>
           <div class="row">
               <div class="col-md-6">
                   <?php echo e(Form::label('theloai', 'Customer')); ?> 
            <?php echo e(Form::select('customer_id',$customers,'',['class'=>'form-control'])); ?>

               </div>
                <div class="col-md-6">
                     <?php echo e(Form::label('', 'status')); ?> 
            <?php echo e(Form::text('status', '',['class' => 'form-control','placeholder'=>'please enter status'])); ?>

            <?php if ($errors->has('status')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('status'); ?>
    <div class="text text-danger"><?php echo e($message); ?></div>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
           </div>
        
        <div class="form-group">
            <?php echo e(Form::label('', 'total_amount')); ?> 
            <?php echo e(Form::number('total_amount', '',['class' => 'form-control','placeholder'=>'please enter total'])); ?>

            <?php if ($errors->has('total_amount')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('total_amount'); ?>
    <div class="text text-danger"><?php echo e($message); ?></div>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        	
		 <div class="form-group">
            <?php echo e(Form::submit('Save',['class' => 'btn btn-primary'])); ?>

            <a href="<?php echo e(url('order')); ?>" class="btn btn-info">Back to List</a>
        </div>
        <?php echo e(Form::close()); ?>

        	</div>
       
        
        
       
    
    </div>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoping\resources\views/frontend/orders/create.blade.php ENDPATH**/ ?>