<?php $__env->startSection('content'); ?>
<div class="col-md-4">
	<?php if(Session::has('update')): ?>
	<div class="alert alert-success text-center">
		<strong>Congratulation</strong>
		<?php echo e(Session::get('update')); ?>

	</div>
	<?php endif; ?>
</div>
<div class="col-md-11">
	<h3 style=" text-transform: uppercase;">Create New Customer</h3>
	<?php echo e(Form::open(['route'=>['customer.update',$ctm->id],'method'=>'put'])); ?>

	<div class="row form-group">
		<div class="col-md-6">
			<?php echo e(Form::label('name')); ?>

		<?php echo e(Form::text('firstname',$ctm->first_name,['class'=>'form-control','placeholder'=>'enter first_name'])); ?>

		<?php if ($errors->has('firstname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('firstname'); ?>
    <div class="text text-danger"><?php echo e($message); ?></div>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
		</div>
		<div class="col-md-6">
			<?php echo e(Form::label('lastname')); ?>

		<?php echo e(Form::text('lastname',$ctm->last_name,['class'=>'form-control','placeholder'=>'enter last_name'])); ?>

		<?php if ($errors->has('lastname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lastname'); ?>
    <div class="text text-danger"><?php echo e($message); ?></div>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
		</div>
	</div>
	<div class="row form-group">
		<div class="col-md-6">
			<?php echo e(Form::label('post_address')); ?>

		<?php echo e(Form::text('paddress',$ctm->post_address,['class'=>'form-control','placeholder'=>'enter post_address'])); ?>

		<?php if ($errors->has('paddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('paddress'); ?>
    <div class="text text-danger"><?php echo e($message); ?></div>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
		</div>
		<div class="col-md-6">
			<?php echo e(Form::label('physical_address')); ?>

		<?php echo e(Form::text('physicaladdress',$ctm->physical_address,['class'=>'form-control','placeholder'=>'enter physical_address'])); ?>

		<?php if ($errors->has('physicaladdress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('physicaladdress'); ?>
    <div class="text text-danger"><?php echo e($message); ?></div>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
		</div>
	</div>
	
	<div class="form-group">
		<?php echo e(Form::label('email')); ?>

		<?php echo e(Form::text('email',$ctm->email,['class'=>'form-control','placeholder'=>'enter email'])); ?>

		<?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
    <div class="text text-danger"><?php echo e($message); ?></div>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
	</div>
	<div class="form-group">
	<?php echo e(Form::submit('send',['class'=>'btn btn-primary'])); ?> 
	<a href="<?php echo e(url('customer')); ?>" class="btn btn-info">Back To List</a>
</div>
	<?php echo e(Form::close()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoping\resources\views/frontend/customer/edit.blade.php ENDPATH**/ ?>