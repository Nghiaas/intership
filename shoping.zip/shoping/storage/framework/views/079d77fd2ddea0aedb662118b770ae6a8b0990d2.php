<?php $__env->startSection('content'); ?>
<div class="col-md-11">
	<div class="col-md-4 mt-1">
		<h4><strong>Tìm thấy <span class="text-danger"><?php echo e(count($product)); ?></span> sản phẩm</strong></h4>
	</div>
	<div class="col-md-8 ">
		 <form class="form-inline" method="get" role="search" action="<?php echo e(route('search')); ?>">
      <input class="form-control " type="search" placeholder="Search" aria-label="Search" name="key" style="margin :4px 0px 2px 10px;">
      <button class="btn btn-secondary" type="submit">Search</button>
    </form>
	</div>
    
	<table class="table table-hover table-bordered text-center table-striped row">
		<thead class="btn-primary">
			<th>No</th>
			<th>Product Code</th>
                <th>Product Name</th>
                <th>Description</th>
                <th>Brand</th>
                <th>Category</th>
                <th>Price</th>
                <th>Image</th>
                <th >Action</th>
		</thead>
		<tbody>
			
			<tr>
				<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<td><?php echo e(++$key); ?></td>
      		<td><?php echo e($products->product_code); ?></td>
          <td><?php echo e($products->product_name); ?></td>
          <td><?php echo e($products->description); ?></td>
            <td><?php echo e($products->brand->name); ?></td>
            <td><?php echo e($products->category->name); ?></td>
      		<td><?php echo e($products->price); ?></td>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
			</tr>
			

		</tbody>
	</table>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoping\resources\views/frontend/product/search.blade.php ENDPATH**/ ?>