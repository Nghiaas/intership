<h3>purchase history</h3>
<div class="col-md-11">
	
	<a href="<?php echo e(url('abc')); ?>" class="btn btn-outline-success" title="Turn Back">Turn Back</a>
	
	<div class="row">
		<div class="col-md-6">
			<table class="table table table-bordered table-hover table-striped">
	<thead class="btn-primary">
		
			 <th>No</th>
            <th>Order_number</th>
            <th>Transactiondate</th>
            <th>Customer</th>
            <th>Status</th>
           
            
		
	</thead>
	<tbody>
		<?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$dh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($key++); ?></td>
			<td><?php echo e($dh->order_number); ?></td>
            <td><?php echo e(date('d-m-Y',strtotime($dh->transaction_date))); ?></td>
            <td><?php echo e($dh->customer->first_name); ?></td>
            <td><?php echo e($dh->status); ?></td>
          
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
	</tbody>
</table></div>
		<div class="col-md-6">
			<table class="table table table-bordered table-hover table-striped">
	<thead class="btn-primary">
		<th>price</th>
		<th>quantity</th>
		<th>total_price</th>
	</thead>
	<tbody>
		<?php $__currentLoopData = $orderdetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $od): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($od->price); ?></td>
			<td><?php echo e($od->quantity); ?></td>
			<td><?php echo e($od->sub_total); ?></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table></div>
</div>
	
<?php echo $__env->make('layouts.link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoping\resources\views/user/ph.blade.php ENDPATH**/ ?>