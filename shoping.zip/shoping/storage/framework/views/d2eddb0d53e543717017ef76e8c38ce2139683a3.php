<?php $__env->startSection('content'); ?>
<div class="col-md-4">
	<?php if(Session::has('message')): ?>
	<div class="alert alert-success text-center">
		<strong>Congratulation</strong>
		<?php echo e(Session::get('message')); ?>

	</div>
	<?php endif; ?>
</div>
<div class="col-md-11">
	<h3 style=" text-transform: uppercase;">Create New Product</h3>
	<?php echo e(Form::open(['url'=>'product','method'=>'post'])); ?>

	<div class="row form-group">
		<div class="col-md-6">
			<?php echo e(Form::label('product_code')); ?>

		<?php echo e(Form::text('code','',['class'=>'form-control','placeholder'=>'enter product_code'])); ?>

		<?php if ($errors->has('code')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('code'); ?>
    <div class="text text-danger"><?php echo e($message); ?></div>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
		</div>
		<div class="col-md-6">
			<?php echo e(Form::label('product_name')); ?>

		<?php echo e(Form::text('name','',['class'=>'form-control','placeholder'=>'enter product_name'])); ?>

		<?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
    <div class="text text-danger"><?php echo e($message); ?></div>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
		</div>
	</div>
	<div class="row form-group">
		<div class="col-md-6">
			<?php echo e(Form::label('brand')); ?>

			<?php echo e(Form::select('brand_id',$brand,'',['class'=>'form-control'])); ?>

		
		</div>
		<div class="col-md-6">
			<?php echo e(Form::label('category')); ?>

			<?php echo e(Form::select('category_id',$category,'',['class'=>'form-control'])); ?>

		</div>
	</div>
	<div class=" form-group">
		
		<?php echo e(Form::label('price')); ?>

		<?php echo e(Form::text('price','',['class'=>'form-control','placeholder'=>'enter price'])); ?>

		<?php if ($errors->has('price')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('price'); ?>
    <div class="text text-danger"><?php echo e($message); ?></div>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
		
	</div>
	<div class="form-group">
		<?php echo e(Form::label('image')); ?>

		<?php echo e(Form::file('image',['class'=>'form-control'])); ?>

	</div>
	
	<div class="form-group">
		<?php echo e(Form::label('description')); ?>

		<?php echo e(Form::textarea('description','',['class'=>'form-control','placeholder'=>'enter description'])); ?>

		<?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
    <div class="text text-danger"><?php echo e($message); ?></div>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
	</div>
	<div class="form-group">
	<?php echo e(Form::submit('send',['class'=>'btn btn-primary'])); ?> 
	<a href="<?php echo e(url('product')); ?>" class="btn btn-info">Back To List</a>
</div>
	<?php echo e(Form::close()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoping\resources\views/frontend/product/create.blade.php ENDPATH**/ ?>