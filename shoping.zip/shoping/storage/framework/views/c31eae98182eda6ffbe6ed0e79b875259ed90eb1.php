<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php echo $__env->yieldContent('content'); ?>

</body>
</html>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoping\resources\views/User/main.blade.php ENDPATH**/ ?>