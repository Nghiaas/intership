
<div class="col-md-11">
	<h3 class="text-center" style="text-transform: uppercase;">Show Product</h3>
	<div class="text-body text-center">
		<div class="row">
			<div class="col-md-3">
				<?php echo e(Form::open()); ?>

				<div class="form-group">
					<?php echo e(Form::label('quantity')); ?>

					<?php echo e(Form::text('quantity','',['class'=>'btn btn-primary','placeholder'=>'enter quantity'])); ?>

				</div>
				<?php echo e(Form::close()); ?>

			
			</div>
			<div class="col-md-9">
				<div class="form-group">
					<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php echo e($c->name); ?>

					<?php echo e($c->description); ?>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				<div class="form-group">

				</div>
			<div class="form-group">
				<a href="<?php echo e(url('abc')); ?>" class="btn btn-info">Back To Home</a>
			</div>
			</div>
		</div>
		
	
	</div>
</div>
<?php /**PATH C:\xampp\htdocs\shoping\resources\views/show.blade.php ENDPATH**/ ?>