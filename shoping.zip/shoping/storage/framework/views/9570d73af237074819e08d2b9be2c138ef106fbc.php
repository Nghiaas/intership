<?php $__env->startSection('content'); ?>
<h3 style="width: 100%; text-align: center;">Order Detail</h3>
        <div class="row">
            <div class="col-md-12">
                <b>Order Code: </b>
                <b style="color:red;"> <?php echo e($order->order_number); ?> </b>
            </div>
            
            <div class="col-md-12">
                <b>Customer Name: </b>
                <b style="color:blue;"><?php echo e($order->customer->first_name); ?> </b>
            </div>    
        </div>
        <br/><b>Order Product</b>
        <?php echo Form::open(['url' => 'order_detail', 'method' => 'post']); ?>

            <?php echo e(Form::label('Product Name:')); ?>

            <?php echo e(Form::hidden('order_id',$order->id)); ?>

            <select class="form-control" id="product_id" name="product_id" name="product_price">
                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($product->id); ?>">
                    <?php echo e($product->product_name); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo e(Form::hidden('price',$product->price)); ?>

            </select><br/> 
            <?php echo e(Form::label('Quantity: ')); ?>

            <?php echo e(Form::number('quantity', '',['class' => 'form-control',])); ?><br/>
            <?php echo e(Form::submit('Buy',['class'=>'btn btn-primary'])); ?>

        <?php echo Form::close(); ?>   

        <br/><table style="text-align: center;" class="table table-bordered table-hover">
            <thead>
            <tr style="background: #9933ff; color: white;">
                <th>Product</th>                         
                <th>Price</th>
                <th>Quantity</th>
                <th>Total Money</th>
            </tr>
            <tbody>
                <?php $__currentLoopData = $order->order_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($order_detail->product->product_name); ?></td>
                    <td><?php echo e($order_detail->product->price); ?></td>
                    <td><?php echo e($order_detail->quantity); ?></td>
                    <td><?php echo e($order_detail->sub_total); ?></td>
                </tr>
                <?php
                    {{  $order->total_amount += $order_detail->sub_total; }}  
                ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                
            </tbody>
        </table>
        <?php
            echo("<b>Total Amount: </b>");
            echo($order->total_amount);
        ?>    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoping\resources\views/frontend/orders/show.blade.php ENDPATH**/ ?>