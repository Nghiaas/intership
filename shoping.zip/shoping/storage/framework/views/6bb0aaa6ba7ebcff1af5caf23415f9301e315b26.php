<?php $__env->startSection('content'); ?>
<div class="col-md-11">
	<h3 class="text-center" style="text-transform: uppercase;">Show Customer</h3>
	  <div class="text-body text-center">
	
			<div class="form-group">
				<strong>FullName:</strong> <?php echo e($customer->first_name." ".$customer->last_name); ?>  <br>
			</div>

			<div class="form-group">
				<strong>Post_Address:</strong> <?php echo e($customer->post_address); ?>  <br>
			</div>
			<div class="form-group">
				<strong>Physical:</strong> <?php echo e($customer->physical_address); ?> <br>
			</div>
			<div class="form-group">
					<strong>Email:</strong> <?php echo e($customer->email); ?>

			</div>
			<div class="form-group">
				<a href="<?php echo e(url('customer')); ?>" class="btn btn-info">Back To List</a>
			</div>
		
		</div>
	
	
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoping\resources\views/frontend/customer/show.blade.php ENDPATH**/ ?>