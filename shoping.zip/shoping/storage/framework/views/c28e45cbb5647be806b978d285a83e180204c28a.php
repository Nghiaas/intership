
    <br/>   
    <div class="row">
        <div class="col-md-8 mx-auto">
          <ul class="list-group">
          <li class="list-group-item active">Product infomation</li>
          <li class="list-group-item"><?php echo e($product->product_name); ?></li>
          <li class="list-group-item"><?php echo e($product->product_code); ?></li>
          <li class="list-group-item"><?php echo e($product->price); ?></li>
          <li class="list-group-item"><?php echo e($product->product_image); ?></li>

        </ul>
        <hr/>
            <?php echo Form::open(['url' => 'checkout', 'method' => 'get']); ?>

            <input type="number" value="<?php echo e($id); ?>" name="id" hidden="hidden"><br/>
            <label>Quantity</label>
            <input class="form-control" type="number" value="1" name="quantity">
                      
            <label>Customer</label>
            <?php echo e(Form::select('customer_id', $customer,'',['class' => 'form-control'])); ?>

            <input type="submit" class="btn btn-primary" value="Checkout">
          <?php echo Form::close(); ?>

            
        </div>
        
    </div>
<?php /**PATH C:\xampp\htdocs\shoping\resources\views/admin/checkout.blade.php ENDPATH**/ ?>