	
<div class="col-md-11">
	<h3 class="text-center" style="text-transform: uppercase;">Show Product</h3>
	<div class="text-body text-center">
		<div class="row">
			<div class="col-md-3">
				
			
			</div>
			<div class="col-md-9">
				<div class="form-group">
				<strong>Product_Code</strong>  </br>
			</div>
			<div class="form-group">
				<strong>Product_Name:</strong> 
			</div>
			<div class="form-group">
				<strong>Price:</strong> 
			</div>
			<div class="form-group">
					<strong>Description:</strong> 
			</div>
			<div class="form-group">
				<a href="{{url('abc')}}" class="btn btn-info">Back To Page Home</a>
			</div>
			</div>
		</div>
		
	
	</div>
</div>

