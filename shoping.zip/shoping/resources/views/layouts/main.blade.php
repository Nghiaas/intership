<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	@include('layouts.header')
	@include('layouts.slide')
	@yield('content')
	@include('layouts.footer')

</body>
@include('layouts.link')
</html>